#!/bin/zsh
# BankSync.app 을 만들고, launchd 가 30분마다 이 앱을 실행하도록 등록한다.
# 앱이 '데스크탑 폴더' 접근 권한만 받아서 sync.py 를 실행한다. (Python 에 넓은 권한을 주지 않음)
# 해제: ./install_schedule.sh uninstall
LABEL="com.bank.autosync"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
APP="$HOME/Applications/BankSync.app"
DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ "$1" == "uninstall" ]]; then
  launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null
  rm -f "$PLIST"
  echo "자동 실행 해제 완료 (앱은 $APP 에 남아 있음, 필요하면 직접 삭제)"
  exit 0
fi

# 1) 미니 앱 만들기 (Dock 아이콘 숨김 → 서명)
mkdir -p "$HOME/Applications" "$HOME/Library/LaunchAgents" "$HOME/Library/Logs"
rm -rf "$APP"
# 스크립트 안의 __BANK_DIR__ 를 이 저장소의 실제 위치로 바꿔서 컴파일
ROOT="$(cd "$DIR/.." && pwd)"
TMP_SCPT="$(mktemp -t bankapp).applescript"
sed "s|__BANK_DIR__|$ROOT|g" "$DIR/app/BankSync.applescript" > "$TMP_SCPT"
osacompile -o "$APP" "$TMP_SCPT" || exit 1
rm -f "$TMP_SCPT"
plutil -replace LSUIElement -bool true "$APP/Contents/Info.plist"
plutil -replace CFBundleIdentifier -string "com.bank.autosync.app" "$APP/Contents/Info.plist"
codesign --force --deep -s - "$APP" || exit 1

# 2) launchd 등록: 30분마다 앱을 백그라운드로 실행
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/open</string>
    <string>-g</string>
    <string>-a</string>
    <string>$APP</string>
  </array>
  <key>StartInterval</key><integer>1800</integer>
  <key>StandardOutPath</key><string>$HOME/Library/Logs/bank-autosync.log</string>
  <key>StandardErrorPath</key><string>$HOME/Library/Logs/bank-autosync.log</string>
</dict>
</plist>
PL
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null
launchctl bootstrap "gui/$(id -u)" "$PLIST" && echo "자동 실행 등록 완료 (30분 간격). 로그: ~/Library/Logs/bank-autosync.log"
