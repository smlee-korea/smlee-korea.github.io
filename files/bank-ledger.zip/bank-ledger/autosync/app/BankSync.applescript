-- BankSync: launchd 가 30분마다 실행하는 미니 앱.
-- 이 앱이 '데스크탑 폴더' 접근 권한을 받고, 그 권한으로 sync.py 를 실행한다.
on run
	try
		do shell script "/usr/bin/python3 '__BANK_DIR__/autosync/sync.py' >> \"$HOME/Library/Logs/bank-autosync.log\" 2>&1"
	on error errMsg
		do shell script "echo \"[BankSync] error: \"" & quoted form of errMsg & " >> \"$HOME/Library/Logs/bank-autosync.log\""
	end try
end run
