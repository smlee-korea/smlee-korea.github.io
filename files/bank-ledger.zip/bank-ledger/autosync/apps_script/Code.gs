/**
 * 은행 알림 수신함 (Google Apps Script)
 *
 * - doPost: 휴대폰(MacroDroid)이 보낸 알림을 'inbox' 시트에 한 줄씩 저장한다.
 * - doGet : Mac 동기화 스크립트가 저장된 알림 목록을 JSON으로 가져간다.
 * - TOKEN 이 일치하지 않는 요청은 모두 거절한다. (외부 유출 금지)
 */
const TOKEN = 'CHANGE_ME';  // ← 아무도 추측할 수 없는 긴 임의 문자열로 바꾸세요 (config.json 의 token 과 같게)
const SHEET_NAME = 'inbox';
const HEADERS = ['id', 'received_at', 'title', 'text', 'app'];

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
  }
  return sh;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const p = (e && e.parameter) || {};
  if (p.token !== TOKEN) return json_({ ok: false, error: 'unauthorized' });

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = getSheet_();
    const id = Utilities.getUuid();
    // 텍스트가 숫자·날짜로 자동 변환되지 않도록 앞에 ' 를 붙여 저장
    sh.appendRow([
      id,
      new Date().toISOString(),
      "'" + (p.title || ''),
      "'" + (p.text || ''),
      p.app || '',
    ]);
    return json_({ ok: true, id: id });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.token !== TOKEN) return json_({ ok: false, error: 'unauthorized' });

  // ping=1 이면 연결 확인만 한다.
  if (p.ping) return json_({ ok: true, pong: true });

  const sh = getSheet_();
  const last = sh.getLastRow();
  const rows = [];
  if (last >= 2) {
    const vals = sh.getRange(2, 1, last - 1, HEADERS.length).getDisplayValues();
    vals.forEach(function (v) {
      if (!v[0]) return;
      rows.push({ id: v[0], received_at: v[1], title: v[2], text: v[3], app: v[4] });
    });
  }
  return json_({ ok: true, rows: rows });
}

/** 편집기에서 직접 실행해 동작을 확인하는 테스트 함수 */
function testInsert() {
  const res = doPost({ parameter: {
    token: TOKEN,
    title: '테스트',
    text: '체크카드 결제 1,000원 테스트가맹점',
    app: 'manual-test',
  } });
  Logger.log(res.getContent());
}
