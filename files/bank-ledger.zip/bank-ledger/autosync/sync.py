#!/usr/bin/env python3
"""
카카오뱅크 알림 → 가계부 자동 기록 스크립트

흐름:
  1) Apps Script 웹앱(doGet)에서 휴대폰이 보낸 알림 목록을 가져온다.
  2) 아직 처리하지 않은 알림만 골라 원문을 data/raw_notifications.jsonl 에 보관한다.
  3) 알림 문구를 해석해 수입/지출·금액·내용·결제수단·카테고리를 뽑는다.
  4) 해석된 거래를 가계부.xlsx 의 '가계부' 시트 빈 행에 추가한다.
  5) 해석 실패/제외된 알림은 data/unparsed.jsonl, data/excluded.jsonl 에 남긴다.

사용법:
  python3 sync.py              # 실제 동기화
  python3 sync.py --dry-run    # 가계부에 쓰지 않고 해석 결과만 출력
  python3 sync.py --ping       # 웹앱 연결만 확인
  python3 sync.py --from-file 파일.json  # 웹앱 대신 로컬 JSON(rows 목록)으로 테스트
"""
import argparse
import datetime as dt
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.parse
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
KST = dt.timezone(dt.timedelta(hours=9))
AMOUNT_RE = re.compile(r"(\d{1,3}(?:,\d{3})+|\d+)\s*원")
BALANCE_RE = re.compile(r"잔액\s*[:：]?\s*[\d,]+\s*원?")
MASKED_NAME_RE = re.compile(r"\S*\*+\S*")  # 예: 이*민, 홍**
ACCOUNT_RE = re.compile(r"[^\s→]*(?:통장|계좌|박스|저금통)\s*\(\d+\)")  # 예: 입출금통장(1234)
TIME_IN_TEXT_RE =re.compile(r"\b\d{1,2}/\d{1,2}\b|\b\d{1,2}:\d{2}\b")


# ---------------------------------------------------------------- 공통
def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def append_jsonl(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def log(data_dir, msg):
    line = f"[{dt.datetime.now(KST):%Y-%m-%d %H:%M:%S}] {msg}"
    print(line)
    with open(os.path.join(data_dir, "sync.log"), "a", encoding="utf-8") as f:
        f.write(line + "\n")


# ---------------------------------------------------------------- 수집
def fetch_rows(cfg, ping=False):
    url = cfg["web_app_url"]
    if not url.startswith("https://"):
        raise RuntimeError("config.json 의 web_app_url 을 먼저 설정하세요.")
    q = {"token": cfg["token"]}
    if ping:
        q["ping"] = "1"
    full = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(q)
    req = urllib.request.Request(full, headers={"User-Agent": "bank-autosync"})
    with urllib.request.urlopen(req, timeout=30) as r:  # Apps Script 는 리다이렉트를 자동으로 따라감
        body = json.loads(r.read().decode("utf-8"))
    if not body.get("ok"):
        raise RuntimeError(f"웹앱 응답 오류: {body}")
    return body if ping else body.get("rows", [])


def to_kst(iso):
    """Apps Script 가 저장한 ISO 시각(UTC, 끝에 Z)을 한국 시간으로 변환"""
    s = iso.strip().replace("Z", "+00:00")
    try:
        t = dt.datetime.fromisoformat(s)
    except ValueError:
        return dt.datetime.now(KST)
    if t.tzinfo is None:
        t = t.replace(tzinfo=dt.timezone.utc)
    return t.astimezone(KST)


# ---------------------------------------------------------------- 해석
def first_match(text, pairs):
    for kw, val in pairs:
        if kw.lower() in text.lower():
            return val
    return None


def parse_notification(row, rules):
    """알림 1건 → 거래 dict. 반환: (status, data)  status ∈ ok / excluded / unparsed"""
    title = (row.get("title") or "").lstrip("'")
    text = (row.get("text") or "").lstrip("'")
    full = f"{title} {text}".strip()
    when = to_kst(row.get("received_at", ""))

    if row.get("app") == "manual-test":  # Apps Script testInsert 로 넣은 테스트 행
        return "excluded", {"reason": "설정 테스트 행", "full": full}
    if any(k in full for k in rules["exclude_keywords"]):
        return "excluded", {"reason": "제외 키워드", "full": full}

    no_balance = BALANCE_RE.sub(" ", full)
    m = AMOUNT_RE.search(no_balance)
    if not m:
        return "unparsed", {"reason": "금액 없음", "full": full}
    amount = int(m.group(1).replace(",", ""))

    is_cancel = any(k in full for k in rules["cancel_keywords"])
    if any(k in full for k in rules["income_keywords"]) and not is_cancel:
        kind = "수입"
    elif any(k in full for k in rules["expense_keywords"]) or is_cancel:
        kind = "지출"
    else:
        return "unparsed", {"reason": "수입/지출 구분 불가", "full": full}

    if is_cancel:
        amount = -amount  # 결제 취소는 음수 지출로 기록 → 합계에서 자동 차감

    # 카카오뱅크 이체 알림 형식: 제목 "출금 1원", 내용 "입출금통장(1234) → 받는사람"
    # 출금이면 화살표 오른쪽(받는 사람), 입금이면 왼쪽(보낸 사람)이 거래 상대
    counterpart = None
    parts = re.split(r"\s*(?:→|->)\s*", BALANCE_RE.sub(" ", text).strip())
    if len(parts) == 2:
        left, right = (ACCOUNT_RE.sub(" ", p).strip() for p in parts)
        counterpart = (right if kind == "지출" else left) or left or right
    # 만원챌린지: 본인 다른 계좌로 하루 생활비를 옮기는 도전 → 수입/지출이 아닌 '챌린지'로 따로 집계
    ch = rules.get("challenge")
    if ch and any(k in full for k in ch["keywords"]) and not is_cancel:
        returned = kind == "수입"  # 챌린지 계좌에서 돌려받은 돈은 음수
        return "ok", {
            "date": when.date(), "time": f"{when:%H:%M}", "kind": ch["kind"], "category": ch["category"],
            "desc": ch["category"], "amount": -amount if returned else amount, "method": "계좌이체",
            "memo": f"자동 {when:%H:%M}" + (" · 챌린지 계좌에서 반환" if returned else ""), "full": full,
        }
    if counterpart and counterpart in rules.get("self_names", []):
        return "excluded", {"reason": "본인 계좌 이체", "full": full}

    # 알림을 보낸 앱으로 은행 구분 (예: 농협 = 만원챌린지 계좌)
    app_name = (row.get("app") or "").lower()
    source = next((s for s in rules.get("sources", []) if any(m.lower() in app_name for m in s["match"])), None)

    # 화살표 형식이 아닌 은행(농협 등)에서 본인 이름이 보이는 입금·이체는 본인 계좌끼리 옮긴 돈으로 보고 제외
    # (예: 카카오뱅크 → 농협 만원챌린지 1만 원 입금. 카카오뱅크 쪽에서 이미 '챌린지'로 집계됨)
    is_card = any(k in full for k in ("카드", "승인", "결제"))
    if not counterpart and not is_card and any(n in full for n in rules.get("self_names", [])):
        return "excluded", {"reason": "본인 계좌 이체", "full": full}

    # 내용(가맹점·보낸 사람) 추출: 금액·잔액·날짜·키워드·기호를 지운 나머지
    # 제목에 금액이 없으면(예: 'NH스마트뱅킹') 앱 이름일 뿐이므로 내용 추출에서 뺀다
    desc_src = full if AMOUNT_RE.search(title) else text
    desc_src = desc_src.replace(row.get("app") or "\0", " ")
    desc_src = MASKED_NAME_RE.sub(" ", desc_src)  # 가려진 이름(이*민) 제거
    desc = ACCOUNT_RE.sub(" ", BALANCE_RE.sub(" ", desc_src))
    am = AMOUNT_RE.search(desc)
    if am:
        desc = desc.replace(am.group(0), " ")
    desc = TIME_IN_TEXT_RE.sub(" ", desc)
    remove_words = (rules["income_keywords"] + rules["expense_keywords"] + rules["cancel_keywords"]
                    + ["카카오뱅크", "NH스마트뱅킹", "NH pay", "NH", "농협", "체크카드", "체크", "알림", "입출금", "님", "[", "]", "|", "(", ")", "·", "-", ":"])
    for w in sorted(set(remove_words), key=len, reverse=True):
        desc = desc.replace(w, " ")
    desc = re.sub(r"\*+", "", desc)          # 마스킹된 이름(홍*동) 처리
    desc = re.sub(r"\s+", " ", desc).strip()[:40]
    if counterpart:
        desc = counterpart[:40]

    cat_pairs = sorted(rules["category_keywords"], key=lambda p: len(p[0]), reverse=True)
    category = first_match(full, cat_pairs)
    income_cats = {"급여", "부수입", "용돈", "이자/배당", "환급", "기타수입"}
    if kind == "수입" and category not in income_cats:
        category = "기타수입"
    if kind == "지출" and (category is None or category in income_cats):
        category = "기타지출"

    method = first_match(full, rules["payment_method_keywords"]) or ("계좌이체" if kind == "수입" else "체크카드")

    memo = f"자동 {when:%H:%M}"
    if source and source["label"] != "카카오뱅크":
        memo += f" · {source['label']}"
        if source.get("challenge_account") and kind == "지출":
            memo += "(챌린지 계좌)"
        if method == "체크카드":
            method = f"{source['label']} 체크카드"
        elif method == "계좌이체" and kind == "지출":
            method = f"{source['label']} 출금"
    if is_cancel:
        memo += " · 결제취소"
    if not desc:
        memo += " · 내용 확인필요"

    return "ok", {
        "date": when.date(), "time": f"{when:%H:%M}", "kind": kind, "category": category,
        "desc": desc or "(내용 없음)", "amount": amount, "method": method, "memo": memo, "full": full,
    }


# ---------------------------------------------------------------- 가계부 기록
def ledger_locked(path):
    d, name = os.path.split(path)
    return os.path.exists(os.path.join(d, "~$" + name))


def append_to_ledger(path, txs):
    from openpyxl import load_workbook
    from openpyxl.workbook.properties import CalcProperties

    wb = load_workbook(path)
    ws = wb["가계부"]
    r = 2
    for tx in txs:
        while any(ws.cell(row=r, column=c).value not in (None, "") for c in range(1, 6)):
            r += 1
        vals = [tx["date"], tx["kind"], tx["category"], tx["desc"], tx["amount"], tx["method"], tx["memo"]]
        for c, v in enumerate(vals, 1):
            ws.cell(row=r, column=c).value = v
        r += 1
    wb.calculation = CalcProperties(fullCalcOnLoad=True)  # 열 때 요약표 자동 재계산

    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=os.path.dirname(path))
    os.close(fd)
    wb.save(tmp)
    shutil.copy2(path, path + ".bak")  # 직전 버전 백업
    os.replace(tmp, path)
    return r - 1


# ---------------------------------------------------------------- 메인
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--ping", action="store_true")
    ap.add_argument("--from-file")
    ap.add_argument("--config", default=os.path.join(BASE, "config.json"))
    args = ap.parse_args()

    cfg = load_json(args.config, None)
    rules = load_json(os.path.join(BASE, "rules.json"), None)
    # 경로를 비워 두면 저장소 폴더 기준 기본값을 쓴다 (가계부.xlsx, data/)
    root = os.path.dirname(BASE)
    cfg["ledger_path"] = cfg.get("ledger_path") or os.path.join(root, "가계부.xlsx")
    cfg["data_dir"] = cfg.get("data_dir") or os.path.join(root, "data")
    data_dir = cfg["data_dir"]
    os.makedirs(data_dir, exist_ok=True)

    if args.ping:
        print(fetch_rows(cfg, ping=True))
        return

    rows = load_json(args.from_file, {"rows": []})["rows"] if args.from_file else fetch_rows(cfg)

    state_path = os.path.join(data_dir, "state.json")
    state = load_json(state_path, {"processed_ids": [], "recent": []})
    done = set(state["processed_ids"])
    new_rows = [r for r in rows if r.get("id") and r["id"] not in done]
    if not new_rows:
        log(data_dir, f"새 알림 없음 (전체 {len(rows)}건)")
        return

    if not args.dry_run and ledger_locked(cfg["ledger_path"]):
        log(data_dir, f"가계부.xlsx 가 열려 있어 이번엔 건너뜀 (대기 {len(new_rows)}건, 다음 실행 때 반영)")
        return

    # 같은 알림이 짧은 시간에 두 번 들어온 경우(알림 갱신 등) 중복 제거용
    recent = state.get("recent", [])
    txs, records = [], []
    counts = {"ok": 0, "excluded": 0, "unparsed": 0, "duplicate": 0}
    for row in new_rows:
        status, data = parse_notification(row, rules)
        key = data["full"]
        t = to_kst(row.get("received_at", "")).timestamp()
        if any(k == key and abs(t - kt) < 120 for k, kt in recent):
            status = "duplicate"
        recent.append([key, t])

        record = {"id": row["id"], "received_at": row.get("received_at"), "status": status,
                  "title": row.get("title"), "text": row.get("text"), "app": row.get("app")}
        records.append((status, record, data))
        counts[status] += 1
        if status == "ok":
            txs.append(data)

        if args.dry_run:
            shown = {k: (str(v) if k == "date" else v) for k, v in data.items() if k != "full"}
            print(f"- [{status}] {data['full']}\n    → {shown}")

    if args.dry_run:
        print(f"\n(dry-run) 결과: {counts}")
        return

    if txs:
        append_to_ledger(cfg["ledger_path"], txs)

    # 가계부 기록이 성공한 뒤에만 원문 보관·처리 완료 표시 (실패 시 다음 실행에서 재시도)
    for status, record, data in records:
        append_jsonl(os.path.join(data_dir, "raw_notifications.jsonl"), record)
        if status in ("excluded", "unparsed"):
            append_jsonl(os.path.join(data_dir, f"{status}.jsonl"), {**record, "reason": data["reason"]})

    state["processed_ids"] = sorted(done | {r["id"] for r in new_rows})
    state["recent"] = [x for x in recent if x[1] > dt.datetime.now(KST).timestamp() - 86400]
    save_json(state_path, state)
    log(data_dir, f"동기화 완료: 기록 {counts['ok']} / 제외 {counts['excluded']} / "
                  f"해석실패 {counts['unparsed']} / 중복 {counts['duplicate']}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # launchd 로그에서 원인을 볼 수 있게 남김
        print(f"오류: {e}", file=sys.stderr)
        sys.exit(1)
