#!/usr/bin/env python3
"""
샘플 데이터 만들기 (모두 가짜 데이터)

실제 은행 알림과 비슷한 가짜 알림을 만든 뒤, 진짜 파서(autosync/sync.py 의 parse_notification)로
해석해서 샘플 가계부를 채운다. 그래서 샘플 화면도 실제 코드가 만든 결과다.

사용법:
  python3 demo/make_sample.py                   # demo/sample/ 에 가계부.xlsx + data/ 생성
  BANK_DIR=demo/sample python3 dashboard/server.py   # 샘플 데이터로 대시보드 열기
"""
import datetime as dt
import json
import os
import random
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "autosync"))
import sync  # noqa: E402

KST = sync.KST
OUT = os.path.join(HERE, "sample")
START, TODAY = dt.date(2026, 9, 1), dt.date(2026, 11, 25)
CHALLENGE_START = dt.date(2026, 11, 3)
SELF = "홍길동"  # 가짜 본인 이름
rnd = random.Random(20261125)

KAKAO, NH = "카카오뱅크", "NH스마트뱅킹"


# ---------------------------------------------------------------- 가짜 알림 문구
def card(amount, merchant):
    return KAKAO, f"결제 {amount:,}원", f"체크카드 {merchant}"


def transfer_out(amount, to):
    return KAKAO, f"출금 {amount:,}원", f"입출금통장(1234) → {to}"


def deposit(amount, frm):
    return KAKAO, f"입금 {amount:,}원", f"{frm} → 입출금통장(1234)"


def nh(kind, amount, when, who, balance):
    text = f"농협 {kind}{amount:,}원\n{when:%m/%d %H:%M} 302-****-0000-00 {who} 잔액{balance:,}원"
    return NH, "입출금 알림", text


# 가맹점 풀: (가맹점, 최소, 최대, 시각 후보)
CAFE = [("메가MGC커피 역삼점", 2000, 4500), ("컴포즈커피 선릉점", 1500, 3800), ("스타벅스 테헤란로점", 4500, 6800),
        ("파리바게뜨 역삼점", 3500, 9000)]
MEAL = [("GS25 역삼센터점", 2500, 8900), ("CU 선릉역점", 1800, 7600), ("세븐일레븐 대치점", 2200, 6400)]
DELIVERY = [("배달의민족", 16000, 31000), ("쿠팡이츠", 14000, 27000), ("요기요", 17000, 29000)]
SHOP = [("쿠팡", 9800, 46000), ("무신사", 29000, 89000), ("다이소 역삼점", 3000, 15000), ("이마트24 역삼점", 3000, 12000)]
FUN = [("CGV 강남", 14000, 28000), ("메가박스 코엑스", 13000, 26000)]
MOVE = [("카카오T 택시", 6800, 18500), ("티머니 충전", 10000, 20000)]
HEALTH = [("온누리약국", 4500, 16000), ("역삼연세의원", 6000, 15000)]
LUNCH_NH = [("GS25 역삼센터점", 2500, 6900), ("CU 선릉역점", 2000, 5900), ("메가MGC커피 역삼점", 2000, 3500),
            ("컴포즈커피 선릉점", 1500, 3000), ("세븐일레븐 대치점", 2500, 6400)]


def price(lo, hi):
    return int(rnd.randint(lo, hi) / 100) * 100


def at(day, h, m=None):
    return dt.datetime(day.year, day.month, day.day, h, m if m is not None else rnd.randint(0, 59), tzinfo=KST)


def make_notifications():
    events = []  # (시각, (app, title, text))
    nh_balance = 0
    d = START
    while d <= TODAY:
        in_challenge = d >= CHALLENGE_START
        # 고정 지출·수입
        if d.day == 1:
            events.append((at(d, 9, 5), transfer_out(450000, "월세 집주인")))
        if d.day == 3:
            events.append((at(d, 4, 12), card(13500, "넷플릭스")))
        if d.day == 7:
            events.append((at(d, 4, 30), card(14900, "유튜브 프리미엄")))
        if d.day == 10:
            events.append((at(d, 10, 0), transfer_out(55000, "SKT 통신요금 자동이체")))
        if d.day == 15:
            events.append((at(d, 10, 0), transfer_out(82000, "보험료 자동이체")))
        if d.day == 25:
            events.append((at(d, 9, 10), deposit(2800000, "샘플컴퍼니 급여")))
            events.append((at(d, 9, 15), transfer_out(300000, "세이프박스")))  # 제외 대상
        if d.day == 18 and d.month == 10:
            events.append((at(d, 20, 3), deposit(150000, "중고거래 판매")))

        # 만원챌린지: 아침에 1만 원을 농협 챌린지 계좌로 옮기고, 그 돈으로 하루를 산다
        if in_challenge:
            t = at(d, 8, rnd.randint(20, 45))
            events.append((t, transfer_out(10000, "만원챌린지")))
            nh_balance += 10000
            events.append((t + dt.timedelta(seconds=20), nh("입금", 10000, t, SELF, nh_balance)))
            budget_day = rnd.random()
            n_items = 1 if budget_day < 0.35 else 2 if budget_day < 0.85 else 3
            for _ in range(n_items):
                who, lo, hi = rnd.choice(LUNCH_NH)
                amt = price(lo, hi)
                when = at(d, rnd.choice([8, 12, 12, 13, 15, 19]))
                nh_balance -= amt
                events.append((when, nh("출금", amt, when, who, max(nh_balance, 0))))
            nh_balance = max(nh_balance, 0)

        # 그 밖의 생활비 (챌린지 기간엔 확 줄어든다)
        if not in_challenge:
            if rnd.random() < 0.08:  # 무지출 데이
                d += dt.timedelta(days=1)
                continue
            for _ in range(rnd.choice([1, 1, 2, 2, 3])):
                m, lo, hi = rnd.choice(CAFE)
                events.append((at(d, rnd.choice([8, 9, 12, 13, 15, 16])), card(price(lo, hi), m)))
            if rnd.random() < 0.55:
                m, lo, hi = rnd.choice(MEAL)
                events.append((at(d, rnd.choice([12, 21, 22, 23, 0])), card(price(lo, hi), m)))
            delivery_p = 0.45 if d.month == 9 else 0.35
            if rnd.random() < delivery_p:
                m, lo, hi = rnd.choice(DELIVERY)
                events.append((at(d, rnd.choice([19, 20, 21, 22, 23])), card(price(lo, hi), m)))
        else:
            if rnd.random() < 0.18:  # 챌린지 중에도 가끔 배달을 시킨다 → ⚠️ 절반 성공
                m, lo, hi = rnd.choice(DELIVERY)
                events.append((at(d, rnd.choice([20, 21, 22])), card(price(lo, hi), m)))
        if rnd.random() < (0.12 if not in_challenge else 0.04):
            m, lo, hi = rnd.choice(SHOP)
            events.append((at(d, rnd.choice([13, 22, 23, 1])), card(price(lo, hi), m)))
        if rnd.random() < 0.07:
            m, lo, hi = rnd.choice(MOVE)
            events.append((at(d, rnd.choice([8, 23, 0])), card(price(lo, hi), m)))
        if d.weekday() >= 5 and rnd.random() < 0.25:
            m, lo, hi = rnd.choice(FUN)
            events.append((at(d, rnd.choice([14, 19])), card(price(lo, hi), m)))
        if rnd.random() < 0.03:
            m, lo, hi = rnd.choice(HEALTH)
            events.append((at(d, 11), card(price(lo, hi), m)))
        if d.day == 12:
            events.append((at(d, 14, 2), (KAKAO, "카카오뱅크", "인증번호 [482913] 타인에게 알려주지 마세요")))
        if d.day == 20:
            events.append((at(d, 18, 30), (KAKAO, "카카오뱅크", "이번 달 혜택을 확인해 보세요")))
        d += dt.timedelta(days=1)

    events = [e for e in events if e[0] <= dt.datetime(2026, 11, 25, 14, 30, tzinfo=KST)]
    events.sort(key=lambda e: e[0])
    rows = []
    for i, (when, (app, title, text)) in enumerate(events):
        utc = when.astimezone(dt.timezone.utc)
        rows.append({"id": f"sample-{i:05d}", "received_at": utc.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                     "title": title, "text": text, "app": app})
    return rows


def main():
    rules = sync.load_json(os.path.join(ROOT, "autosync", "rules.json"), None)
    rules["self_names"] = [SELF]
    rows = make_notifications()

    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    data_dir = os.path.join(OUT, "data")
    os.makedirs(data_dir)
    ledger = os.path.join(OUT, "가계부.xlsx")

    # 빈 템플릿에서 예시 2줄을 지우고 시작
    from openpyxl import load_workbook
    wb = load_workbook(os.path.join(ROOT, "ledger_template.xlsx"))
    ws = wb["가계부"]
    for r in (2, 3):
        for c in range(1, 8):
            ws.cell(row=r, column=c).value = None
    wb.save(ledger)

    txs, counts = [], {"ok": 0, "excluded": 0, "unparsed": 0, "duplicate": 0}
    raw_path = os.path.join(data_dir, "raw_notifications.jsonl")
    for row in rows:
        status, data = sync.parse_notification(row, rules)
        counts[status] += 1
        record = {k: row[k] for k in ("id", "received_at", "title", "text", "app")}
        record["status"] = status
        sync.append_jsonl(raw_path, record)
        if status in ("excluded", "unparsed"):
            sync.append_jsonl(os.path.join(data_dir, f"{status}.jsonl"), {**record, "reason": data["reason"]})
        if status == "ok":
            txs.append(data)
    sync.append_to_ledger(ledger, txs)
    os.remove(ledger + ".bak")

    with open(os.path.join(data_dir, "sync.log"), "w", encoding="utf-8") as f:
        f.write("[2026-11-25 14:00:03] 새 알림 없음 (전체 %d건)\n" % (len(rows) - 2))
        f.write("[2026-11-25 14:30:02] 동기화 완료: 기록 2 / 제외 0 / 해석실패 0 / 중복 0\n")
    print(f"샘플 생성 완료: 알림 {len(rows)}건 → {counts}  ({OUT})")


if __name__ == "__main__":
    main()
