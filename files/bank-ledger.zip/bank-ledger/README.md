# 알림 가계부 자동화

은행 앱의 **결제·이체 푸시 알림**을 받아 Mac의 엑셀 가계부(`가계부.xlsx`)에 자동으로 기록하고, 그 기록으로 소비 습관을 분석하는 개인용 도구입니다.

카카오뱅크처럼 PC와 연동되지 않는 은행도 알림만 오면 기록할 수 있습니다. 가계부 분석은 모두 내 Mac 안(127.0.0.1)에서만 이루어지고, 외부 API를 쓰지 않습니다.

```
[은행 앱 결제·이체] → 휴대폰 푸시 알림
  → MacroDroid(Android)가 은행 앱 알림만 골라 구글로 전송 (토큰 포함)
  → 내 구글 시트 'inbox'에 쌓임 (Mac이 꺼져 있어도 보관)
  → Mac이 30분마다 가져와 해석한 뒤 가계부.xlsx에 기록
  → 대시보드 앱(BankDashboard)으로 분석 결과 보기
```

## 주요 기능

- **자동 기록**: 금액, 수입·지출, 거래처, 카테고리, 결제수단을 알림 문구에서 뽑아냅니다. 규칙은 `autosync/rules.json`에서 키워드로 고칩니다.
- **걸러내기**: 세이프박스·적금 이동, 본인 계좌 간 이체, 인증번호·광고 알림은 기록하지 않습니다. 결제 취소는 음수 지출로 기록하고, 2분 안에 다시 온 같은 알림은 중복으로 처리합니다.
- **여러 은행 지원**: 알림을 보낸 앱 이름으로 은행을 구분합니다. 예시 설정에는 카카오뱅크와 농협이 들어 있습니다.
- **안전한 기록**: 엑셀이 열려 있으면 그 회차는 건너뜁니다. 임시 파일에 저장한 뒤 교체하고, 직전 버전을 `.bak`으로 남깁니다. 실패하면 다음 회차에 다시 시도합니다.
- **대시보드 (7개 탭)**: 요약 · 생활 규칙 · 지출 분석 · 소비 패턴 · 💪 챌린지 · 거래 내역 · 시트
- **생활 규칙**: 배달 횟수, 밤 결제, 소액 결제, 저축률 같은 패턴을 찾아 근거와 함께 규칙을 제안합니다. 계산 규칙만 쓰고 AI API는 쓰지 않습니다.
- **만원챌린지**: 매일 1만 원을 다른 계좌로 옮겨 그 돈으로만 사는 도전입니다. 남은 돈을 이월하는 방식으로 날짜별 성공 여부를 판정합니다.

## 먼저 샘플로 보기

가짜 데이터로 대시보드를 바로 열어볼 수 있습니다. (Python 3, `pip3 install openpyxl` 필요)

```bash
python3 demo/make_sample.py                          # demo/sample/ 에 가짜 알림 301건 → 샘플 가계부 생성
BANK_DIR=demo/sample python3 dashboard/server.py     # http://127.0.0.1:8765 에서 열림
```

## 설치

필요한 것: **Android 휴대폰**, **Mac**, **구글 계정**, Python 3 + `openpyxl`

### 1. 구글 시트 + Apps Script (알림 우편함)

1. [sheets.new](https://sheets.new)에서 새 시트를 만듭니다.
2. **확장 프로그램 → Apps Script**에 `autosync/apps_script/Code.gs`를 통째로 붙여 넣습니다.
3. 맨 위 `TOKEN`을 아무도 추측할 수 없는 긴 임의 문자열로 바꿉니다. (예: `python3 -c "import secrets; print(secrets.token_urlsafe(24))"`)
4. `testInsert`를 한 번 실행해 권한을 허용합니다. `inbox` 탭에 테스트 한 줄이 생기면 성공입니다.
5. **배포 → 새 배포 → 웹 앱**을 고릅니다. 실행 사용자는 "나", 액세스는 "모든 사용자"로 정합니다. 토큰이 맞아야만 응답하므로 괜찮습니다. 나온 웹앱 URL을 복사합니다.

### 2. 휴대폰 MacroDroid

1. **트리거**: 알림 수신 → 은행 앱만 선택
2. **액션**: HTTP 요청 → `POST`, URL은 웹앱 URL
3. 쿼리 매개변수 4개를 넣습니다. 값은 입력칸 옆 매직 텍스트 버튼에서 고르세요.

   | 이름 | 값 |
   |---|---|
   | `token` | 1단계에서 정한 토큰 |
   | `title` | `{not_title}` (알림 제목) |
   | `text` | `{notification}` (알림 내용) |
   | `app` | `{not_app_name}` (앱 이름) |

4. MacroDroid 배터리 설정을 **제한 없음**으로 바꿉니다. 바꾸지 않으면 알림을 놓칠 수 있습니다.

### 3. Mac

```bash
cp autosync/config.example.json autosync/config.json   # web_app_url, token 채우기
cp ledger_template.xlsx 가계부.xlsx
python3 autosync/sync.py --ping       # 연결 확인
python3 autosync/sync.py --dry-run    # 가계부에 쓰지 않고 해석 결과만 보기
./autosync/install_schedule.sh        # 30분마다 자동 동기화 (BankSync.app + launchd)
./dashboard/install_app.sh            # ~/Applications/BankDashboard.app 설치
```

- `autosync/rules.json`의 `self_names`에 **본인 이름**을 넣어야 본인 계좌 간 이체가 지출로 잡히지 않습니다.
- 처음 실행할 때 macOS가 데스크탑(또는 저장소가 있는 폴더) 접근 권한을 물으면 허용하세요.
- 해제: `./autosync/install_schedule.sh uninstall`, `./dashboard/install_app.sh uninstall`

## 왜 미니앱을 거쳐 실행하나요?

launchd에서 `python3`를 바로 실행하면 macOS 보안(TCC)이 데스크탑 폴더 접근을 막습니다. Python에 전체 디스크 접근 권한을 주는 대신, **필요한 폴더 권한만 받은 AppleScript 미니앱**(BankSync.app)을 launchd가 실행하고, 그 앱이 `sync.py`를 돌립니다.

## 파일 구성

| 경로 | 역할 |
|---|---|
| `autosync/apps_script/Code.gs` | 구글 시트 알림 우편함 (doPost 저장 / doGet 조회, 토큰 검사) |
| `autosync/sync.py` | 가져오기 → 해석 → 가계부 기록 |
| `autosync/rules.json` | 해석 규칙 (제외 키워드, 가맹점 → 카테고리, 은행 구분, 챌린지) |
| `autosync/config.example.json` | 설정 예시. `config.json`으로 복사해서 사용 (git에 올리지 않음) |
| `autosync/install_schedule.sh` | BankSync.app 생성 + 30분 자동 실행 등록 |
| `dashboard/server.py` | 127.0.0.1 전용 읽기 전용 서버, 분석·생활 규칙·챌린지 판정 |
| `dashboard/static/index.html` | 대시보드 화면 (라이브러리 없이 직접 그린 차트, 라이트·다크 모드) |
| `dashboard/install_app.sh` | BankDashboard.app 생성 |
| `ledger_template.xlsx` | 빈 가계부 (월별요약·카테고리 시트 수식 포함) |
| `demo/make_sample.py` | 가짜 알림으로 샘플 가계부 만들기 |
| `data/` (자동 생성) | 받은 알림 원문, 제외·해석 실패 기록, 동기화 로그 (git에 올리지 않음) |

## 개인정보

- `config.json`(웹앱 주소·토큰), `가계부.xlsx`, `data/`는 `.gitignore`로 막아 두었습니다. 포크해서 쓸 때도 올리지 마세요.
- 토큰은 비밀번호와 같습니다. 유출되면 `Code.gs`와 `config.json`의 토큰을 새 값으로 바꾸고 웹앱을 다시 배포하세요.
