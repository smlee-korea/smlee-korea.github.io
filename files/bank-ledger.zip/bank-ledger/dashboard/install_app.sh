#!/bin/zsh
# 가계부 대시보드 앱(BankDashboard.app)을 ~/Applications 에 만든다.
# 제거: ./install_app.sh uninstall
APP="$HOME/Applications/BankDashboard.app"
DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ "$1" == "uninstall" ]]; then
  pkill -f "$DIR/server.py" 2>/dev/null
  rm -rf "$APP"
  echo "대시보드 앱 제거 완료"
  exit 0
fi

mkdir -p "$HOME/Applications" "$HOME/Library/Logs"
rm -rf "$APP"
# 스크립트 안의 __BANK_DIR__ 를 이 저장소의 실제 위치로 바꿔서 컴파일
ROOT="$(cd "$DIR/.." && pwd)"
TMP_SCPT="$(mktemp -t bankapp).applescript"
sed "s|__BANK_DIR__|$ROOT|g" "$DIR/app/BankDashboard.applescript" > "$TMP_SCPT"
osacompile -o "$APP" "$TMP_SCPT" || exit 1
rm -f "$TMP_SCPT"
plutil -replace CFBundleIdentifier -string "com.bank.dashboard.app" "$APP/Contents/Info.plist"
plutil -replace LSUIElement -bool true "$APP/Contents/Info.plist"
# 가계부 아이콘 적용 (초록 배경 + $ 동전). Assets.car 의 기본 아이콘 대신 applet.icns 를 쓰도록 설정
if [[ -f "$DIR/app/AppIcon.icns" ]]; then
  cp "$DIR/app/AppIcon.icns" "$APP/Contents/Resources/applet.icns"
  plutil -remove CFBundleIconName "$APP/Contents/Info.plist" 2>/dev/null
  rm -f "$APP/Contents/Resources/Assets.car"
fi
codesign --force --deep -s - "$APP" || exit 1
echo "설치 완료: $APP"
