#!/usr/bin/env python3
"""
내 가계부 대시보드 서버 (읽기 전용)

- 127.0.0.1(내 Mac 안)에서만 열리는 작은 웹 서버다. 외부로 데이터를 보내지 않는다.
- 가계부.xlsx 와 data/ 폴더를 읽어 분석 결과를 JSON 으로 제공하고, 화면(static/index.html)을 띄운다.
- 가계부.xlsx 는 절대 수정하지 않는다. ("지금 동기화" 버튼은 기존 autosync/sync.py 를 실행할 뿐)
- 이미 서버가 떠 있으면 창만 다시 연다. 창이 닫히고 IDLE_TIMEOUT 동안 요청이 없으면 스스로 종료한다.
"""
import calendar
import datetime as dt
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BANK = os.environ.get("BANK_DIR") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # BANK_DIR=demo/sample 로 샘플 데이터 보기
LEDGER = os.path.join(BANK, "가계부.xlsx")
DATA_DIR = os.path.join(BANK, "data")
SYNC_PY = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "autosync", "sync.py")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
HOST, PORT = "127.0.0.1", 8765
URL = f"http://{HOST}:{PORT}/"
IDLE_TIMEOUT = 600  # 초. 화면이 60초마다 신호를 보내므로 창이 열려 있는 동안은 꺼지지 않음
CHROME = "/Applications/Google Chrome.app"

WEEKDAYS = ["월", "화", "수", "목", "금", "토", "일"]
TIMESLOTS = [("새벽", 0, 6), ("아침", 6, 11), ("점심", 11, 14), ("오후", 14, 18), ("저녁", 18, 21), ("밤", 21, 24)]
FIXED_CATS = {"주거/관리비", "통신비", "보험", "교육"}
MEMO_TIME_RE = re.compile(r"자동\s+(\d{1,2}):(\d{2})")
CHALLENGE_ACCOUNT_TAG = "챌린지 계좌"  # sync.py 가 농협(챌린지 계좌) 지출 메모에 붙이는 표시

_last_seen = time.time()


# ---------------------------------------------------------------- 데이터 읽기
def load_transactions():
    from openpyxl import load_workbook

    wb = load_workbook(LEDGER, read_only=True, data_only=True)
    ws = wb["가계부"]
    txs = []
    for row in ws.iter_rows(min_row=2, max_col=7, values_only=True):
        d, kind, cat, desc, amount, method, memo = (list(row) + [None] * 7)[:7]
        if d is None or amount in (None, "") or kind not in ("수입", "지출", "챌린지"):
            continue
        memo = str(memo or "")
        if "예시" in memo:  # 템플릿 예시 행은 분석에서 제외
            continue
        if isinstance(d, dt.datetime):
            d = d.date()
        elif isinstance(d, str):
            try:
                d = dt.date.fromisoformat(d.strip()[:10])
            except ValueError:
                continue
        if not isinstance(d, dt.date):
            continue
        try:
            amount = float(amount)
        except (TypeError, ValueError):
            continue
        m = MEMO_TIME_RE.search(memo)
        txs.append({
            "date": d, "kind": kind, "cat": cat or ("기타수입" if kind == "수입" else "기타지출"),
            "desc": str(desc or "").strip() or "(내용 없음)", "amount": amount,
            "method": method or "", "memo": memo,
            "hour": int(m.group(1)) if m else None,
            "time": f"{int(m.group(1)):02d}:{m.group(2)}" if m else "",
        })
    wb.close()
    return txs


def sync_status():
    path = os.path.join(DATA_DIR, "sync.log")
    if not os.path.exists(path):
        return {"last": None, "message": "아직 동기화 기록이 없어요"}
    with open(path, encoding="utf-8") as f:
        lines = [l.strip() for l in f if l.strip()]
    if not lines:
        return {"last": None, "message": "아직 동기화 기록이 없어요"}
    m = re.match(r"\[(.+?)\]\s*(.*)", lines[-1])
    return {"last": m.group(1) if m else None, "message": m.group(2) if m else lines[-1]}


# ---------------------------------------------------------------- 분석
def month_key(d):
    return f"{d.year:04d}-{d.month:02d}"


def won(n):
    return f"{int(round(n)):,}원"


def challenge_calendar(txs, y, mo, days_in_month, today):
    """만원챌린지 달력 (전액 이월 방식)
    그날 예산 = 전날까지 남은 돈(이월) + 그날 챌린지 계좌로 보낸 금액
    ✅ 챌린지 계좌 지출 ≤ 예산 이고 다른 계좌 생활비 없음 / ⚠️ 예산은 지켰지만 다른 계좌에서도 씀 / ❌ 예산 초과
    초과한 날 다음 날 이월은 0원부터 다시 시작한다. 이월은 달을 넘어서도 이어진다."""
    daily = defaultdict(lambda: {"transfer": 0.0, "spent": 0.0, "other": 0.0, "items": [], "other_items": []})
    for t in txs:
        d = daily[t["date"]]
        if t["kind"] == "챌린지":
            d["transfer"] += t["amount"]
        elif t["kind"] == "지출" and CHALLENGE_ACCOUNT_TAG in t["memo"]:
            d["spent"] += t["amount"]
            d["items"].append(f'{t["desc"]} {int(t["amount"]):,}원')
        elif t["kind"] == "지출" and t["cat"] not in FIXED_CATS and t["amount"] > 0:
            d["other"] += t["amount"]
            d["other_items"].append(f'{t["desc"]} {int(t["amount"]):,}원')

    empty = {"transfer": 0.0, "spent": 0.0, "other": 0.0, "items": [], "other_items": []}
    joined_of = lambda v: v["transfer"] != 0 or v["spent"] > 0
    month_start = dt.date(y, mo, 1)

    # 이번 달 1일 전까지의 이월 금액 계산
    carry = 0.0
    chal_dates = sorted(d for d, v in daily.items() if joined_of(v))
    if chal_dates and chal_dates[0] < month_start:
        d = chal_dates[0]
        while d < month_start and d <= today:
            v = daily.get(d)
            if v and joined_of(v):
                carry = max(carry + v["transfer"] - v["spent"], 0.0)
            d += dt.timedelta(days=1)
    carry_from_prev = carry

    days = []
    for day in range(1, days_in_month + 1):
        date = dt.date(y, mo, day)
        v = daily.get(date, empty)
        joined = joined_of(v)
        carry_in = carry
        budget = carry + v["transfer"]
        if date > today:
            status = "future"
        elif not joined:
            status = "none"
        elif v["spent"] > budget:
            status = "fail"
        elif date == today:
            status = "today"
        elif v["other"] > 0:
            status = "half"
        else:
            status = "success"
        days.append({
            "day": day, "weekday": (date.weekday() + 1) % 7,  # 0=일요일
            "status": status, "carry_in": carry_in, "transfer": v["transfer"],
            "budget": budget if joined else 0, "spent": v["spent"], "other": v["other"],
            "items": v["items"], "other_items": v["other_items"],
        })
        if date <= today and joined:
            carry = max(budget - v["spent"], 0.0)

    done = [x for x in days if x["status"] in ("success", "half", "fail")]
    succ = [x for x in done if x["status"] == "success"]
    streak = 0  # 오늘(진행 중)은 빼고 어제부터 거꾸로. 챌린지 안 한 날은 연속을 끊지 않음
    for x in reversed(done):
        if x["status"] != "success":
            break
        streak += 1
    best = run = 0
    for x in done:
        run = run + 1 if x["status"] == "success" else 0
        best = max(best, run)
    today_info = next((x for x in days if x["status"] == "today"), None)
    return {
        "mode": "carryover",
        "days": days,
        "first_weekday": days[0]["weekday"] if days else 0,
        "joined": len(done) + (1 if today_info else 0),
        "success": len(succ), "half": len([x for x in done if x["status"] == "half"]),
        "fail": len([x for x in done if x["status"] == "fail"]),
        "rate": (len(succ) / len(done)) if done else None,
        "streak": streak, "best": best,
        "balance": carry,  # 지금 챌린지 계좌에 남아 있어야 할 돈 (이월 포함)
        "carry_from_prev": carry_from_prev,
        "month_transfer": sum(x["transfer"] for x in days),
        "month_spent": sum(x["spent"] for x in days),
        "avg_spent": (sum(x["spent"] for x in done) / len(done)) if done else None,
        "today": today_info,
    }


def analyze(month=None):
    txs = load_transactions()
    today = dt.date.today()
    months = sorted({month_key(t["date"]) for t in txs} | {month_key(today)}, reverse=True)
    if month not in months:
        month = month_key(today)
    y, mo = map(int, month.split("-"))
    days_in_month = calendar.monthrange(y, mo)[1]
    is_current = (y, mo) == (today.year, today.month)
    elapsed = today.day if is_current else days_in_month
    if (y, mo) > (today.year, today.month):
        elapsed = 0

    cur = [t for t in txs if month_key(t["date"]) == month]
    prev_y, prev_m = (y, mo - 1) if mo > 1 else (y - 1, 12)
    prev = [t for t in txs if (t["date"].year, t["date"].month) == (prev_y, prev_m)]
    exp = [t for t in cur if t["kind"] == "지출"]
    inc = [t for t in cur if t["kind"] == "수입"]
    chal = [t for t in cur if t["kind"] == "챌린지"]  # 만원챌린지: 수입·지출과 별도 집계
    # 습관 분석용: 월세·통신비 같은 고정지출은 패턴(요일·시간대 등)을 왜곡하므로 제외
    var_exp = [t for t in exp if t["cat"] not in FIXED_CATS]

    income = sum(t["amount"] for t in inc)
    expense = sum(t["amount"] for t in exp)
    prev_expense = sum(t["amount"] for t in prev if t["kind"] == "지출")
    # 지난달 같은 기간(1일~오늘 날짜)과 비교해야 공정함
    prev_same = sum(t["amount"] for t in prev if t["kind"] == "지출" and t["date"].day <= elapsed) if is_current else prev_expense

    # 카테고리
    cat_sum, cat_cnt = defaultdict(float), Counter()
    for t in exp:
        cat_sum[t["cat"]] += t["amount"]
        if t["amount"] > 0:
            cat_cnt[t["cat"]] += 1
    categories = sorted(
        ({"name": c, "amount": a, "count": cat_cnt[c], "share": (a / expense if expense > 0 else 0)}
         for c, a in cat_sum.items() if a > 0),
        key=lambda x: -x["amount"])

    # 일별
    daily = [0.0] * days_in_month
    for t in var_exp:
        daily[t["date"].day - 1] += t["amount"]
    daily_list = [{"day": i + 1, "amount": a, "future": (i + 1) > elapsed} for i, a in enumerate(daily)]

    # 요일별
    wd = [0.0] * 7
    for t in var_exp:
        wd[t["date"].weekday()] += t["amount"]
    weekday = [{"label": WEEKDAYS[i], "amount": wd[i]} for i in range(7)]

    # 시간대별 (자동 기록 행만 시각이 있음)
    slots = {name: [0.0, 0] for name, _, _ in TIMESLOTS}
    timed = 0
    for t in var_exp:
        if t["hour"] is None or t["amount"] <= 0:
            continue
        timed += 1
        for name, a, b in TIMESLOTS:
            if a <= t["hour"] < b:
                slots[name][0] += t["amount"]
                slots[name][1] += 1
    timeslot = [{"label": n, "amount": slots[n][0], "count": slots[n][1]} for n, _, _ in TIMESLOTS]

    # 가맹점 TOP 5
    mer_sum, mer_cnt = defaultdict(float), Counter()
    for t in var_exp:
        if t["amount"] > 0:
            mer_sum[t["desc"]] += t["amount"]
            mer_cnt[t["desc"]] += 1
    merchants = sorted(({"name": k, "amount": v, "count": mer_cnt[k]} for k, v in mer_sum.items()),
                       key=lambda x: (-x["count"], -x["amount"]))[:5]

    # 무지출일, 소액결제
    spent_days = {t["date"].day for t in var_exp if t["amount"] > 0}
    no_spend = sum(1 for d in range(1, elapsed + 1) if d not in spent_days)
    small = [t for t in var_exp if 0 < t["amount"] < 10000]

    summary = {
        "income": income, "expense": expense, "net": income - expense,
        "savings_rate": ((income - expense) / income) if income > 0 else None,
        "prev_expense_same_period": prev_same,
        "expense_change": ((expense - prev_same) / prev_same) if prev_same > 0 else None,
        "no_spend_days": no_spend, "elapsed_days": elapsed,
        "small_count": len(small), "small_sum": sum(t["amount"] for t in small),
        "tx_count": len(cur), "timed_count": timed,
        "fixed_expense": sum(t["amount"] for t in exp if t["cat"] in FIXED_CATS),
        "challenge_sum": sum(t["amount"] for t in chal),
        "challenge_days": len({t["date"] for t in chal if t["amount"] > 0}),
    }

    ctx = {"exp": exp, "expense": expense, "income": income, "categories": categories, "timeslot": timeslot,
           "timed": timed, "summary": summary, "elapsed": elapsed, "weekday": weekday,
           "prev": prev, "prev_same": prev_same, "is_current": is_current}
    enough = len([t for t in exp if t["amount"] > 0]) >= 5 and elapsed >= 7
    rules = make_rules(ctx) if enough else []

    trans = sorted(cur, key=lambda t: (t["date"], t["time"]), reverse=True)
    challenge = challenge_calendar(txs, y, mo, days_in_month, today)
    return {
        "month": month, "months": months, "is_current": is_current, "enough_data": enough,
        "challenge": challenge,
        "summary": summary, "categories": categories, "daily": daily_list, "weekday": weekday,
        "timeslot": timeslot, "merchants": merchants, "rules": rules,
        "category_names": sorted({t["cat"] for t in cur}),
        "transactions": [{**t, "date": t["date"].isoformat()} for t in trans],
        "sync": sync_status(), "generated_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
    }


# ---------------------------------------------------------------- 생활 규칙 (Mac 안의 계산 규칙)
def make_rules(c):
    """데이터에서 패턴을 찾아 근거와 함께 규칙을 제안한다. score 가 높은 순으로 최대 5개."""
    out = []
    weeks = max(c["elapsed"] / 7.0, 1.0)
    cats = {x["name"]: x for x in c["categories"]}
    expense = c["expense"]

    d = cats.get("배달")
    if d and (d["count"] / weeks > 2 or d["share"] >= 0.10):
        per_week = d["count"] / weeks
        target = max(1, int(per_week) - 1)
        out.append({"icon": "🛵", "score": 80 + d["share"] * 100, "title": "배달 줄이기",
                    "evidence": f"이번 달 배달 {d['count']}회 · {won(d['amount'])} (지출의 {d['share']:.0%}), 주 평균 {per_week:.1f}회",
                    "rule": f"배달은 주 {target}회까지"})

    if c["timed"] >= 3:
        night = sum(x["amount"] for x in c["timeslot"] if x["label"] in ("밤", "새벽"))
        night_cnt = sum(x["count"] for x in c["timeslot"] if x["label"] in ("밤", "새벽"))
        timed_sum = sum(x["amount"] for x in c["timeslot"])
        share = night / timed_sum if timed_sum > 0 else 0
        if share >= 0.25 and night_cnt >= 3:
            out.append({"icon": "🌙", "score": 70 + share * 100, "title": "밤 결제 멈추기",
                        "evidence": f"시각이 기록된 지출 중 {share:.0%}({night_cnt}건, {won(night)})가 밤 9시~새벽 6시",
                        "rule": "밤 9시 이후엔 장바구니에만 담고, 결제는 다음 날 아침에"})

    s = c["summary"]
    var_total = sum(t["amount"] for t in c["exp"] if t["cat"] not in FIXED_CATS)
    if s["small_count"] >= 15 or (var_total > 0 and s["small_sum"] / var_total >= 0.15 and s["small_count"] >= 8):
        out.append({"icon": "🪙", "score": 60 + s["small_count"], "title": "소액 결제 관리",
                    "evidence": f"1만 원 미만 결제 {s['small_count']}회, 합계 {won(s['small_sum'])}",
                    "rule": "1만 원 미만 결제는 하루 2번까지"})

    cafe = cats.get("카페/간식")
    if cafe and (cafe["count"] / weeks > 3 or cafe["amount"] >= 40000):
        per_week = cafe["count"] / weeks
        out.append({"icon": "☕", "score": 55 + cafe["share"] * 100, "title": "카페·간식 횟수 정하기",
                    "evidence": f"카페/간식 {cafe['count']}회 · {won(cafe['amount'])}, 주 평균 {per_week:.1f}회",
                    "rule": f"카페는 주 {max(2, int(per_week) - 1)}회까지, 나머지는 텀블러·집 커피"})

    if c["elapsed"] >= 7 and s["no_spend_days"] / c["elapsed"] < 0.15:
        out.append({"icon": "🗓️", "score": 50, "title": "무지출 데이 만들기",
                    "evidence": f"{c['elapsed']}일 중 돈을 안 쓴 날이 {s['no_spend_days']}일",
                    "rule": "일주일에 하루는 무지출 데이 (예: 수요일)"})

    if c["income"] > 0 and s["savings_rate"] is not None and s["savings_rate"] < 0.2:
        out.append({"icon": "🐷", "score": 75 + (0.2 - s["savings_rate"]) * 100, "title": "먼저 저축하기",
                    "evidence": f"이번 달 저축률 {s['savings_rate']:.0%} (수입 {won(c['income'])} 중 {won(max(s['net'], 0))} 남음)",
                    "rule": "수입이 들어온 날, 20%를 세이프박스로 먼저 옮기기"})

    if s["expense_change"] is not None and s["expense_change"] >= 0.2 and c["prev_same"] > 0:
        prev_cat = defaultdict(float)
        for t in c["prev"]:
            if t["kind"] == "지출" and (not c["is_current"] or t["date"].day <= c["elapsed"]):
                prev_cat[t["cat"]] += t["amount"]
        diff = sorted(((x["amount"] - prev_cat.get(x["name"], 0), x["name"]) for x in c["categories"]), reverse=True)
        top = diff[0] if diff else (0, "")
        out.append({"icon": "📈", "score": 65 + s["expense_change"] * 50, "title": "지출 증가 점검",
                    "evidence": f"지난달 같은 기간보다 지출 {s['expense_change']:.0%} 증가, 가장 많이 늘어난 곳: {top[1]} (+{won(top[0])})",
                    "rule": f"{top[1]} 이번 주 예산을 먼저 정하고 쓰기"})

    variable = [x for x in c["categories"] if x["name"] not in FIXED_CATS]
    if variable and variable[0]["share"] >= 0.35:
        v = variable[0]
        budget = int(round(v["amount"] * 0.8 / 10000.0)) * 10000
        out.append({"icon": "🎯", "score": 58 + v["share"] * 50, "title": f"{v['name']} 예산 정하기",
                    "evidence": f"{v['name']}이(가) 지출의 {v['share']:.0%} ({won(v['amount'])})",
                    "rule": f"다음 달 {v['name']} 예산 {budget:,}원 (이번 달의 80%)"})

    wk = c["weekday"]
    total_wd = sum(x["amount"] for x in wk)
    if total_wd > 0 and (wk[5]["amount"] + wk[6]["amount"]) / total_wd >= 0.45:
        share = (wk[5]["amount"] + wk[6]["amount"]) / total_wd
        out.append({"icon": "🛍️", "score": 52, "title": "주말 지출 계획",
                    "evidence": f"지출의 {share:.0%}가 토·일요일에 몰려 있어요",
                    "rule": "금요일 저녁에 주말 예산을 정해두기"})

    out.sort(key=lambda r: -r["score"])
    for r in out:
        r.pop("score", None)
    return out[:5]


# ---------------------------------------------------------------- 시트 보기
CONFIG = os.path.join(BANK, "autosync", "config.json")
STATUS_KO = {"ok": "기록됨", "excluded": "제외", "unparsed": "해석 실패", "duplicate": "중복"}


def _cell(v):
    if isinstance(v, dt.datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.strftime("%Y-%m-%d %H:%M")
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def read_jsonl(path):
    out = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except ValueError:
                        pass
    return out


def sheet_data(year=None):
    """가계부.xlsx 의 '가계부' 시트 원본 + 월별요약(직접 계산) + 받은 알림 원문"""
    from openpyxl import load_workbook

    wb = load_workbook(LEDGER, read_only=True, data_only=True)
    ws = wb["가계부"]
    headers, rows = [], []
    for i, row in enumerate(ws.iter_rows(min_row=1, max_col=7, values_only=True), start=1):
        vals = [_cell(v) for v in row]
        if i == 1:
            headers = [str(v or "") for v in vals]
            continue
        if any(v not in (None, "") for v in vals):
            rows.append({"row": i, "cells": vals})
    wb.close()

    # 월별 요약: 엑셀 '월별요약' 시트와 같은 계산 (분석과 같은 기준으로 예시 행은 제외)
    txs = load_transactions()
    years = sorted({t["date"].year for t in txs} | {dt.date.today().year}, reverse=True)
    year = int(year) if year and str(year).isdigit() and int(year) in years else years[0]
    monthly, cum = [], 0.0
    cat_names = []
    cat_matrix = defaultdict(lambda: [0.0] * 12)
    for m in range(1, 13):
        mt = [t for t in txs if t["date"].year == year and t["date"].month == m]
        inc = sum(t["amount"] for t in mt if t["kind"] == "수입")
        exp = sum(t["amount"] for t in mt if t["kind"] == "지출")
        chal = sum(t["amount"] for t in mt if t["kind"] == "챌린지")
        cum += inc - exp
        monthly.append({"month": m, "income": inc, "expense": exp, "net": inc - exp,
                        "rate": ((inc - exp) / inc) if inc > 0 else None, "cum": cum, "challenge": chal})
        for t in mt:
            if t["kind"] == "지출":
                cat_matrix[t["cat"]][m - 1] += t["amount"]
    cats = sorted(cat_matrix.items(), key=lambda kv: -sum(kv[1]))
    cat_rows = [{"name": k, "months": v, "total": sum(v)} for k, v in cats if sum(v) != 0]

    # 받은 알림 원문 (최근 300건)
    reasons = {r["id"]: r.get("reason", "") for name in ("unparsed", "excluded")
               for r in read_jsonl(os.path.join(DATA_DIR, f"{name}.jsonl"))}
    raw = []
    for r in read_jsonl(os.path.join(DATA_DIR, "raw_notifications.jsonl"))[-300:]:
        when = r.get("received_at") or ""
        try:
            t = dt.datetime.fromisoformat(when.replace("Z", "+00:00")).astimezone(dt.timezone(dt.timedelta(hours=9)))
            when = t.strftime("%Y-%m-%d %H:%M")
        except ValueError:
            pass
        raw.append({"when": when, "title": (r.get("title") or "").lstrip("'"), "text": (r.get("text") or "").lstrip("'"),
                    "status": STATUS_KO.get(r.get("status"), r.get("status")), "reason": reasons.get(r.get("id"), "")})
    raw.reverse()

    cfg = {}
    if os.path.exists(CONFIG):
        with open(CONFIG, encoding="utf-8") as f:
            cfg = json.load(f)
    gurl = cfg.get("google_sheet_url", "")
    return {
        "headers": headers, "rows": rows, "year": year, "years": years,
        "monthly": monthly, "cat_rows": cat_rows, "raw": raw,
        "google_sheet_url": gurl if gurl.startswith("https://docs.google.com/") else "",
        "ledger_name": os.path.basename(LEDGER),
    }


def open_target(target):
    """정해진 대상만 연다 (임의 경로 열기 금지)"""
    if target == "ledger":
        subprocess.Popen(["/usr/bin/open", LEDGER])
    elif target == "folder":
        subprocess.Popen(["/usr/bin/open", "-R", LEDGER])
    else:
        return False
    return True


# ---------------------------------------------------------------- 웹 서버
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False))

    def do_GET(self):
        global _last_seen
        _last_seen = time.time()
        u = urllib.parse.urlparse(self.path)
        if u.path in ("/", "/index.html"):
            with open(os.path.join(STATIC, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if u.path == "/api/ping":
            return self._json({"ok": True})
        if u.path == "/api/data":
            month = urllib.parse.parse_qs(u.query).get("month", [None])[0]
            try:
                return self._json({"ok": True, **analyze(month)})
            except Exception as e:  # 가계부를 못 읽어도 화면에 이유를 보여줌
                return self._json({"ok": False, "error": str(e)}, 500)
        if u.path == "/api/sheet":
            year = urllib.parse.parse_qs(u.query).get("year", [None])[0]
            try:
                return self._json({"ok": True, **sheet_data(year)})
            except Exception as e:
                return self._json({"ok": False, "error": str(e)}, 500)
        self._send(404, "not found", "text/plain; charset=utf-8")

    def do_POST(self):
        global _last_seen
        _last_seen = time.time()
        # 다른 웹사이트가 내 Mac 서버를 건드리지 못하게 같은 출처 요청만 허용
        origin = self.headers.get("Origin")
        if origin and origin.rstrip("/") != URL.rstrip("/"):
            return self._json({"ok": False, "error": "forbidden"}, 403)
        if urllib.parse.urlparse(self.path).path == "/api/sync":
            try:
                r = subprocess.run([sys.executable, SYNC_PY], capture_output=True, text=True, timeout=90)
                msg = (r.stdout.strip().splitlines() or [""])[-1] or r.stderr.strip()
                return self._json({"ok": r.returncode == 0, "message": msg})
            except subprocess.TimeoutExpired:
                return self._json({"ok": False, "message": "동기화 시간이 초과됐어요"}, 504)
        if urllib.parse.urlparse(self.path).path == "/api/open":
            target = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("target", [""])[0]
            return self._json({"ok": open_target(target)})
        self._send(404, "not found", "text/plain; charset=utf-8")


def server_running():
    try:
        with urllib.request.urlopen(URL + "api/ping", timeout=1.5) as r:
            return r.status == 200
    except Exception:
        return False


def open_window():
    if os.path.exists(CHROME):
        # 탭·주소창 없는 앱 전용 창으로 열기
        subprocess.Popen(["/usr/bin/open", "-na", CHROME, "--args", f"--app={URL}", "--window-size=1280,900"])
    else:
        subprocess.Popen(["/usr/bin/open", URL])


def watchdog(httpd):
    while True:
        time.sleep(30)
        if time.time() - _last_seen > IDLE_TIMEOUT:
            httpd.shutdown()
            return


def main():
    no_open = "--no-open" in sys.argv
    if server_running():
        if not no_open:
            open_window()
        return
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    threading.Thread(target=watchdog, args=(httpd,), daemon=True).start()
    if not no_open:
        open_window()
    httpd.serve_forever()


if __name__ == "__main__":
    main()
