-- BankDashboard: 더블클릭하면 가계부 대시보드 창을 연다.
-- 이 앱이 '데스크탑 폴더' 접근 권한을 받고, 그 권한으로 server.py(내 Mac 전용 서버)를 띄운다.
on run
	do shell script "/usr/bin/python3 '__BANK_DIR__/dashboard/server.py' >> \"$HOME/Library/Logs/bank-dashboard.log\" 2>&1 &"
end run
