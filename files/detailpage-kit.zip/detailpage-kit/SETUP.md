# 상세페이지 제작 키트 설치 안내 (Windows)

제품 사진을 주면 Claude Code가 `/detailpage` 스킬로 에이블리 스타일 상세페이지(780px JPG, 1000px 썸네일, 쿠팡 등록용 README)를 만들어 줘요.
처음 한 번만 아래 순서대로 설치하면 돼요. Mac도 같은 순서이고, 명령이 다른 곳은 따로 적었어요.

## 1. 프로그램 설치 (한 번만)

| 프로그램 | 설치 방법 | 왜 필요한가 |
|---|---|---|
| Git for Windows | https://git-scm.com/download/win (기본값으로 설치) | Claude Code가 명령을 실행할 때 씀 (Git Bash) |
| Python 3.10 이상 | https://www.python.org/downloads/ → 설치 첫 화면에서 **"Add python.exe to PATH" 체크** | 사진 다듬기·JPG 만들기 |
| Google Chrome | https://www.google.com/chrome/ | 상세페이지를 JPG로 찍기 (없으면 Edge로 대신 찍어요) |
| Claude Code | PowerShell에서 `irm https://claude.ai/install.ps1 \| iex` | 스킬을 실행하는 프로그램 |
| Claude in Chrome 확장 | Chrome 웹스토어에서 "Claude" 검색 → 설치 → Claude 계정으로 로그인 | 쿠팡 벤치마킹, 제품 사진 검색 |

Claude는 **Pro 이상 구독** 계정으로 로그인해요. Claude Code와 Claude in Chrome 둘 다 같은 계정으로 쓰면 돼요.

## 2. 키트 받기 (한 번만)

1. https://smlee-korea.github.io/#detailpage-kit 에서 **`detailpage-kit.zip`**을 내려받아요.
2. 압축을 풀어 `문서`(Documents) 폴더에 둬요. `문서\detailpage-kit` 폴더를 열었을 때 `CLAUDE.md`, `SETUP.md`, `tools` 가 바로 보여야 해요.
   (압축 풀기가 `detailpage-kit\detailpage-kit`처럼 한 겹 더 만들면 안쪽 폴더를 꺼내 주세요.)
3. Git Bash(시작 메뉴 → Git Bash)를 열고 Python 준비물을 설치해요.

```bash
cd ~/Documents/detailpage-kit
py -m venv .venv
.venv/Scripts/python.exe -m pip install -r requirements.txt
```

- 문서 폴더가 OneDrive로 백업되는 컴퓨터면 첫 줄을 `cd ~/OneDrive/Documents/detailpage-kit`(또는 `~/OneDrive/문서/detailpage-kit`)로 바꿔요.
- Mac은 `py` 대신 `python3`, `.venv/Scripts/python.exe` 대신 `.venv/bin/python`을 써요.

## 3. 사용하기

```bash
cd ~/Documents/detailpage-kit
claude
```

1. 처음 실행하면 Claude 계정 로그인 창이 떠요. 로그인해요.
2. Claude Code 안에서 `/chrome`을 입력해 Chrome 연결을 켜요 (처음 한 번).
3. 제품 사진을 `inbox` 폴더에 넣고 이렇게 입력해요.
   ```
   /detailpage inbox/사진.png
   ```
   사진 파일을 터미널 창으로 끌어다 놓거나, 공급처 상품 링크를 붙여 넣어도 돼요.
4. 끝나면 `<영문-상품명>/output/` 폴더에 결과가 생겨요.
   - `detail_full.jpg`: 상세페이지 전체 (쿠팡에 올릴 것)
   - `detail_01.jpg` …: 길이를 나눈 상세페이지
   - `thumb_main_1000.jpg`, `thumb_addN_1000.jpg`: 대표·추가 이미지
   - 상품 폴더의 `README.md`: 쿠팡 등록값(상품명, 옵션, 태그, 가격)과 올리기 전 확인할 것

## 4. 업데이트 받기

스킬이 바뀌었다고 하면 1단계 주소에서 zip을 다시 받아 **같은 자리에 덮어쓰기**로 풀어요.
만들어 둔 상품 폴더와 `.venv`는 zip에 없어서 그대로 남아요.

## 문제가 생기면

| 증상 | 해결 |
|---|---|
| `Chrome을 찾지 못했어요` | Chrome을 설치하거나, 다른 위치에 설치했다면 `export CHROME="/c/경로/chrome.exe"` 뒤 다시 실행 |
| `No module named PIL` | 2단계의 `pip install` 줄을 다시 실행 |
| `py`가 없다고 나옴 | Python 설치 때 "Add python.exe to PATH"를 체크하지 않은 것. Python을 다시 설치 |
| `/detailpage`가 안 보임 | `detailpage-kit` 폴더 안에서 `claude`를 실행했는지, 폴더가 한 겹 더 생기지 않았는지 확인 |
| 쿠팡·구글 검색을 못 함 | Chrome에 Claude 확장이 설치·로그인돼 있는지, Claude Code에서 `/chrome`이 켜져 있는지 확인 |

## 주의
- 캐릭터·브랜드 상품은 라이선스 증빙이 없으면 판매하지 않아요. README의 "올리기 전 확인"을 꼭 봐요.
- 상품 작업 폴더는 각자 컴퓨터에만 남아요.
