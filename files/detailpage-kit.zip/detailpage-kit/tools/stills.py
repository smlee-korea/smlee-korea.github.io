"""제품 사진 1장으로 에이블리 스타일 연출컷(스틸컷) 여러 장을 합성한다.

사용법 (store 폴더에서, PY = Windows `.venv/Scripts/python.exe` / Mac `.venv/bin/python`):
    PY tools/stills.py <상품폴더> <원본사진> [--seed x,y ...] [--cut-below y]
예:
    PY tools/stills.py chiikawa-airpods-case source.png --seed 455,196 --cut-below 283

- 원본은 <상품폴더>/assets 기준. 배경이 단색(흰색·연회색)인 단독 컷이어야 잘 오려진다.
- --seed: 고리 안쪽처럼 테두리와 이어지지 않은 배경 구멍의 좌표 (원본 픽셀 기준, 여러 개 가능)
- --cut-below: 원본 바닥 그림자를 지울 y 좌표 (이 아래는 모두 배경 처리)
- --erase "x,y x,y x,y ...": 사진에 같이 찍힌 다른 물건을 배경색으로 지울 다각형 (여러 개 가능)
- --flush-bottom: 제품이 사진 아래 끝에서 잘려 있을 때. 연출컷에서 제품을 아래 끝에 붙여 배치하고 그림자를 넣지 않는다

만드는 파일 (assets/):
    clean.png   배경을 흰색으로 정리한 원본 (썸네일용)
    cutout.png  배경을 투명하게 오려낸 제품
    shot1.jpg   흰 배경 정사각 (대표 연출컷)
    shot4.jpg   라벤더 배경 + 그림자
    shot5.jpg   핑크 배경 + 살짝 기울임
    shot6.jpg   민트 배경 + 작게, 반대로 기울임
    shot8.jpg   제품 왼쪽 확대 (정사각)
    shot9.jpg   제품 오른쪽 확대 (정사각)
원본 해상도가 낮으면(가로 1000px 미만) 확대 컷이 흐리다. README에 사진 교체를 적는다.
"""
import argparse
import os

from PIL import Image, ImageDraw, ImageFilter, ImageOps

S = 1512  # 756px 칸의 2배
KEY = (255, 0, 255)


def bg_color(src):
    w, h = src.size
    cs = [src.getpixel(p) for p in [(2, 2), (w - 3, 2), (2, h - 3), (w - 3, h - 3)]]
    return max(cs, key=lambda c: sum(sum(abs(a - b) for a, b in zip(c, d)) < 30 for d in cs) * 1000 + sum(c))


def cutout(src, seeds, cut_below):
    w, h = src.size
    k = src.copy()
    bg = bg_color(src)
    near = lambda c: sum(abs(a - b) for a, b in zip(c, bg)) < 45
    for p in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1), (w // 2, 2), (w // 2, h - 2), *seeds]:
        if p in seeds or near(src.getpixel(p)):  # 제품 위에서 시작하지 않게 배경색인 곳만
            ImageDraw.floodfill(k, p, KEY, thresh=40)
    mask = Image.new("L", (w, h), 0)
    kp, mp, lp = k.load(), mask.load(), src.convert("L").load()
    for y in range(h):
        for x in range(w):
            if kp[x, y] == KEY or (cut_below and y >= cut_below):
                continue
            # 바닥 근처의 옅은 회색(그림자)은 버린다
            if cut_below and y >= cut_below - 8 and lp[x, y] > 130:
                continue
            mp[x, y] = 255
    mask = mask.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(0.8))
    clean = Image.composite(src, Image.new("RGB", src.size, "white"), mask)
    cut = src.copy()
    cut.putalpha(mask)
    box = mask.getbbox()
    return clean, cut.crop(box), box


def stage(cut, bg, scale, angle=0, dy=-20, shadow=True, flush=False):
    c = Image.new("RGB", (S, S), bg)
    if flush:  # 아래가 잘린 제품: 아래 끝에 붙이고 그림자 없음
        W = int(S * scale)
        H = round(cut.height * W / cut.width)
        p = cut.resize((W, H), Image.LANCZOS)
        if angle:
            p = p.rotate(angle, resample=Image.BICUBIC, expand=False)
        c.paste(p, ((S - W) // 2, S - H), p)
        return c
    W = int(S * scale)
    H = round(cut.height * W / cut.width)
    if H > S * 0.8:
        H = int(S * 0.8)
        W = round(cut.width * H / cut.height)
    p = cut.resize((W, H), Image.LANCZOS)
    if angle:
        p = p.rotate(angle, resample=Image.BICUBIC, expand=True)
    x, y = (S - p.width) // 2, (S - p.height) // 2 + dy
    if shadow:
        a = p.split()[3].resize((p.width, max(1, p.height // 6)))
        sh = Image.new("L", (S, S), 0)
        sh.paste(a, (x + int(W * 0.03), y + p.height - int(p.height * 0.10)))
        sh = sh.filter(ImageFilter.GaussianBlur(22)).point(lambda v: int(v * 0.55))
        dark = Image.new("RGB", (S, S), tuple(int(v * 0.70) for v in bg))
        c = Image.composite(dark, c, sh)
    c.paste(p, (x, y), p)
    return c


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("source")
    ap.add_argument("--seed", action="append", default=[])
    ap.add_argument("--cut-below", type=int, default=0)
    ap.add_argument("--erase", action="append", default=[])
    ap.add_argument("--flush-bottom", action="store_true")
    a = ap.parse_args()
    A = os.path.join(os.path.abspath(a.folder), "assets")
    src = Image.open(os.path.join(A, a.source)).convert("RGB")
    seeds = [tuple(map(int, s.split(","))) for s in a.seed]
    if a.erase:
        d = ImageDraw.Draw(src)
        for poly in a.erase:
            d.polygon([tuple(map(int, xy.split(","))) for xy in poly.split()], fill=bg_color(src))
        src.save(os.path.join(A, "erased.png"))
    clean, cut, box = cutout(src, seeds, a.cut_below)
    clean.save(os.path.join(A, "clean.png"))
    cut.save(os.path.join(A, "cutout.png"))
    f = a.flush_bottom
    if f:  # 아래가 잘린 사진은 원본 비율 그대로 크게, 기울이지 않는다
        sc = [0.98, 0.92, 0.86, 0.80]
        ang = [0, 0, 0, 0]
    else:
        sc = [0.86, 0.80, 0.74, 0.66]
        ang = [0, 0, -9, 7]
    stage(cut, (255, 255, 255), sc[0], ang[0], shadow=False, flush=f).save(os.path.join(A, "shot1.jpg"), quality=93)
    stage(cut, (236, 231, 246), sc[1], ang[1], flush=f).save(os.path.join(A, "shot4.jpg"), quality=93)
    stage(cut, (252, 232, 236), sc[2], ang[2], -30, flush=f).save(os.path.join(A, "shot5.jpg"), quality=93)
    stage(cut, (228, 242, 236), sc[3], ang[3], -30, flush=f).save(os.path.join(A, "shot6.jpg"), quality=93)
    # 확대 컷: 제품 영역 안쪽에서 왼쪽·오른쪽 정사각
    x0, y0, x1, y1 = box
    side = min(int((x1 - x0) * 0.42), y1 - y0)
    cy = (y0 + y1) // 2
    for name, cx in [("shot8.jpg", x0 + int((x1 - x0) * 0.30)), ("shot9.jpg", x0 + int((x1 - x0) * 0.62))]:
        crop = src.crop((cx - side // 2, cy - side // 2, cx + side // 2, cy + side // 2))
        ImageOps.fit(crop, (S, S)).save(os.path.join(A, name), quality=93)
    print("완료:", "clean.png cutout.png shot1 shot4 shot5 shot6 shot8 shot9", "| 원본 크기", src.size)
    if src.width < 1000:
        print("주의: 원본이 작아 확대 컷이 흐릴 수 있어요")
