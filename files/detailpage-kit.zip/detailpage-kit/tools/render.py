"""상품 폴더의 detail.html을 쿠팡 상세 이미지(가로 780px JPG)로 렌더링하고,
흰 배경 1000x1000 대표/추가 이미지를 만든다.

사용법 (store 폴더에서, PY = Windows `.venv/Scripts/python.exe` / Mac `.venv/bin/python`):
    PY tools/render.py <상품폴더> [대표이미지 추가이미지 ...]
예:
    PY tools/render.py nike-killshot2-432997-121 side.png pair.png sole.png

- 이미지 파일명은 <상품폴더>/assets 기준. 첫 번째가 대표 이미지(thumb_main), 나머지는 thumb_add1, thumb_add2 ...
- 생략하면 assets/shot1.png, shot2.png, shot3.png 중 있는 것을 사용한다.
- Chrome(없으면 Edge)을 자동으로 찾는다. 다른 위치에 있으면 환경변수 CHROME에 실행 파일 경로를 넣는다.
"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

from PIL import Image


def find_chrome():
    """운영체제별로 Chrome(없으면 Edge) 실행 파일을 찾는다."""
    if os.environ.get("CHROME"):
        return os.environ["CHROME"]
    cands = []
    if sys.platform == "darwin":
        cands = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    elif os.name == "nt":
        for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            base = os.environ.get(env)
            if base:
                cands.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES"):
            base = os.environ.get(env)
            if base:
                cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
    for c in cands:
        if os.path.exists(c):
            return c
    for name in ("google-chrome", "chrome", "chromium", "msedge"):
        if shutil.which(name):
            return shutil.which(name)
    sys.exit("Chrome을 찾지 못했어요. Chrome을 설치하거나 환경변수 CHROME에 실행 파일 경로를 넣어주세요.")


CHROME = find_chrome()
WIDTH = 780
SCALE = 2            # 2배로 찍은 뒤 축소해 글자를 선명하게
MAX_H = 16000        # 렌더링 창 높이(페이지보다 넉넉하게)
PIECE_H = 2000       # 분할 이미지 한 장의 최대 높이
MARK = (255, 0, 255) # html 배경 표시색(페이지 끝 감지용). 템플릿의 html{background:#ff00ff} 와 짝


def render(d, out):
    raw = os.path.join(out, "_raw.png")
    subprocess.run([
        CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
        f"--force-device-scale-factor={SCALE}",
        f"--window-size={WIDTH},{MAX_H}",
        "--virtual-time-budget=8000",
        f"--screenshot={raw}",
        Path(d, "detail.html").resolve().as_uri(),  # Windows 경로(C:\...)도 file:/// 주소로 바꾼다
    ], check=True, capture_output=True)

    im = Image.open(raw).convert("RGB")
    px = im.load()
    bottom = im.height
    for y in range(im.height - 1, -1, -1):
        if px[10, y] != MARK or px[im.width - 10, y] != MARK:
            bottom = y + 1
            break
    if bottom >= im.height - 1:
        print("경고: 페이지가 렌더링 창보다 길어 잘렸을 수 있어요. MAX_H를 늘리세요.")
    im = im.crop((0, 0, im.width, bottom)).resize((WIDTH, round(bottom / SCALE)), Image.LANCZOS)
    os.remove(raw)

    for f in os.listdir(out):  # 이전 분할본 정리
        if f.startswith("detail_") and f.endswith(".jpg"):
            os.remove(os.path.join(out, f))

    full = os.path.join(out, "detail_full.jpg")
    im.save(full, quality=92, optimize=True)
    print("전체:", im.size, f"{os.path.getsize(full)/1024:.0f}KB")
    n = 0
    for y in range(0, im.height, PIECE_H):
        n += 1
        im.crop((0, y, WIDTH, min(y + PIECE_H, im.height))).save(
            os.path.join(out, f"detail_{n:02d}.jpg"), quality=92, optimize=True)
    print("분할:", n, "장")


def square(d, out, src, name, ratio=0.86):
    s = Image.open(os.path.join(d, "assets", src)).convert("RGB")
    w = int(1000 * ratio)
    h = round(s.height * w / s.width)
    if h > int(1000 * ratio):  # 세로로 긴 사진은 높이 기준으로 맞춤
        h = int(1000 * ratio)
        w = round(s.width * h / s.height)
    s = s.resize((w, h), Image.LANCZOS)
    c = Image.new("RGB", (1000, 1000), "white")
    c.paste(s, ((1000 - w) // 2, (1000 - h) // 2))
    c.save(os.path.join(out, name), quality=95)
    print("정사각:", name, "←", src)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    d = os.path.abspath(sys.argv[1])
    out = os.path.join(d, "output")
    os.makedirs(out, exist_ok=True)
    render(d, out)
    thumbs = sys.argv[2:] or [f for f in ("shot1.png", "shot2.png", "shot3.png")
                              if os.path.exists(os.path.join(d, "assets", f))]
    for i, t in enumerate(thumbs):
        square(d, out, t, "thumb_main_1000.jpg" if i == 0 else f"thumb_add{i}_1000.jpg")
